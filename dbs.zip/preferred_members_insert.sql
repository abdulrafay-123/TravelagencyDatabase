insert into preferred_members (Memberid, number_of_followers) values (105, 32);
insert into preferred_members (Memberid, number_of_followers) values (110, 39);
insert into preferred_members (Memberid, number_of_followers) values (164, 32);
insert into preferred_members (Memberid, number_of_followers) values (166, 26);
insert into preferred_members (Memberid, number_of_followers) values (177, 22);
insert into preferred_members (Memberid, number_of_followers) values (182, 23);
insert into preferred_members (Memberid, number_of_followers) values (189, 30);
insert into preferred_members (Memberid, number_of_followers) values (198, 32);
insert into preferred_members (Memberid, number_of_followers) values (215, 40);
insert into preferred_members (Memberid, number_of_followers) values (216, 27);
insert into preferred_members (Memberid, number_of_followers) values (220, 35);
insert into preferred_members (Memberid, number_of_followers) values (230, 28);
insert into preferred_members (Memberid, number_of_followers) values (242, 23);
insert into preferred_members (Memberid, number_of_followers) values (249, 24);
insert into preferred_members (Memberid, number_of_followers) values (259, 37);
insert into preferred_members (Memberid, number_of_followers) values (266, 17);
insert into preferred_members (Memberid, number_of_followers) values (267, 39);
insert into preferred_members (Memberid, number_of_followers) values (273, 39);
insert into preferred_members (Memberid, number_of_followers) values (285, 21);
insert into preferred_members (Memberid, number_of_followers) values (286, 33);
insert into preferred_members (Memberid, number_of_followers) values (290, 31)

select * from preferred_members;