insert into BusinessPartner (BpID, BusinessName, BusinessType, destinationid, Contact_Person, business_contact_number) values (14, 'CBR inc.', 'Mall', 52, 'Donovan Wanek', 1892346981);
insert into BusinessPartner (BpID, BusinessName, BusinessType, destinationid, Contact_Person, business_contact_number) values (49, 'infinity inc', 'Mall', 21, 'Laurena Danslow', 2643714681);
insert into BusinessPartner (BpID, BusinessName, BusinessType, destinationid, Contact_Person, business_contact_number) values (88, 'GVK inc', 'Mall', 5, 'Corrianne Houtbie', 3526138291);
insert into BusinessPartner (BpID, BusinessName, BusinessType, destinationid, Contact_Person, business_contact_number) values (10, 'Inorbit inc', 'Mall', 98, 'Genna Goldes', 1112221297);
insert into BusinessPartner (BpID, BusinessName, BusinessType, destinationid, Contact_Person, business_contact_number) values (78, 'Chanakya inc', 'Mall', 27, 'Gris Omond', 999213456);
insert into BusinessPartner (BpID, BusinessName, BusinessType, destinationid, Contact_Person, business_contact_number) values (42, 'Roadhouse org', 'Restaurant', 62, 'Lonnard Golightly', 8491733610);
insert into BusinessPartner (BpID, BusinessName, BusinessType, destinationid, Contact_Person, business_contact_number) values (5, 'MAMAs org', 'Restaurant', 3, 'Virgilio Bardell', 1002003000);
insert into BusinessPartner (BpID, BusinessName, BusinessType, destinationid, Contact_Person, business_contact_number) values (70, 'Happys Fish house org', 'Restaurant', 96, 'Maryann Bwye', 4781489999);
insert into BusinessPartner (BpID, BusinessName, BusinessType, destinationid, Contact_Person, business_contact_number) values (48, 'Villa org', 'Restaurant', 95, 'Geno Croall', 8788781234);
insert into BusinessPartner (BpID, BusinessName, BusinessType, destinationid, Contact_Person, business_contact_number) values (31, 'Shah ghouse brothers', 'Restaurant', 7, 'Perceval Brahmer', 6667773456);

select * from businesspartner;