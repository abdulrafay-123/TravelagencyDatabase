insert into visited_Destination (Memberid, visitedlist) values
(105, 'Art Institute of Chicago, CBR Mall, Red Fort, Faneuil Hall, Texas Roadhouse, Vieux Lyon'),
(110, 'Kalamazoo, Beaux-Arts museum, '),
(112, 'Eifel Tower, Notre-Dame Cathedral'),
(122, 'Eifel Tower, Shah Ghouse Restaurant, House of Blues Dallas'),
(125, 'The Sice Route, Great Wall of China, Tamra Restaurant, Notre-Dame Cathedral'),
(277, 'Eifel Tower, Shah Ghouse Restaurant, Connecticut River Walk, Vieux Port, Stonestown Galleria, infinity mall'),
(279, 'Crocker Art Museuem, CBR Mall, Texas Roadhouse'),
(281, 'Kalamazoo, Crocker Art Museuem, CBR Mall, Red Fort, Faneuil Hall, Texas Roadhouse, Vieux Lyon'),
(285, 'infinity mall, Salarjung Museum, Notre-Dame Cathedral, Petite France district, Brickell City Centre, Eifel Tower'),
(286, 'CityWalk Mall, Pista House Restaurant, The Chanakya Mall, Eifel Tower, Red Fort'),
(290, 'Eifel Tower, Notre-Dame Cathedral, The Chanakya Mall, Petite France district, Brickell City Centre');

select * from visited_destination;