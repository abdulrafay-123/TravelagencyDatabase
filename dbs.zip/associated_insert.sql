insert into associated (BpID, destinationid) values (14, 52);
insert into associated (BpID, destinationid) values (49, 21);
insert into associated (BpID, destinationid) values (88, 5);
insert into associated (BpID, destinationid) values (10, 98);
insert into associated (BpID, destinationid) values (78, 27);
insert into associated (BpID, destinationid) values (42, 62);
insert into associated (BpID, destinationid) values (5, 3);
insert into associated (BpID, destinationid) values (70, 96);
insert into associated (BpID, destinationid) values (48, 95);
insert into associated (BpID, destinationid) values (31, 7);

select * from associated;