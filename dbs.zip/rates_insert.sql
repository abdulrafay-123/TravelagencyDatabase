insert into Rates (Memberid, destinationid, Planid, plan_rating, rateid) values (110, 24, 55, 2, 101);
insert into Rates (Memberid, destinationid, Planid, plan_rating, rateid) values (203, 25, 22, 2, 102);
insert into Rates (Memberid, destinationid, Planid, plan_rating, rateid) values (259, 57, 4, 2, 103);
insert into Rates (Memberid, destinationid, Planid, plan_rating, rateid) values (236, 66, 41, 4, 104);
insert into Rates (Memberid, destinationid, Planid, plan_rating, rateid) values (198, 27, 33, 2, 105);
insert into Rates (Memberid, destinationid, Planid, plan_rating, rateid) values (188, 90, 14, 2, 106);
insert into Rates (Memberid, destinationid, Planid, plan_rating, rateid) values (105, 62, 67, 4, 107);
insert into Rates (Memberid, destinationid, Planid, plan_rating, rateid) values (125, 75, 10, 4, 108);
insert into Rates (Memberid, destinationid, Planid, plan_rating, rateid) values (220, 96, 20, 3, 109);
insert into Rates (Memberid, destinationid, Planid, plan_rating, rateid) values (112, 57, 49, 5, 110);
insert into Rates (Memberid, destinationid, Planid, plan_rating, rateid) values (285, 65, 83, 4, 111);
insert into Rates (Memberid, destinationid, Planid, plan_rating, rateid) values (128, 41, 44, 2, 112);

select * from rates;