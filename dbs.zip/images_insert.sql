insert into images (Memberid, Destinationid, destinationname, imageid, imagelink) values (110, 52, 'CBR Mall', 28, 'http://images.com/227x100.png/cc0000/ffffff');
insert into images (Memberid, Destinationid, destinationname, imageid, imagelink) values (203, 21, 'innfinity mall', 96, 'http://images.com/111x100.png/5fa2dd/ffffff');
insert into images (Memberid, Destinationid, destinationname, imageid, imagelink) values (259, 2, 'Eifel Tower', 37, 'http://images.com/131x100.png/5fa2dd/ffffff');
insert into images (Memberid, Destinationid, destinationname, imageid, imagelink) values (236, 40, 'Brickell City Centre', 83, 'http://images.com/129x100.png/dddddd/000000');
insert into images (Memberid, Destinationid, destinationname, imageid, imagelink) values (198, 36, 'Notre-Dame Cathedral', 23, 'http://images.com/177x100.png/5fa2dd/ffffff');
insert into images (Memberid, Destinationid, destinationname, imageid, imagelink) values (188, 12, 'Vieux Port', 43, 'http://images.com/231x100.png/ff4444/ffffff');
insert into images (Memberid, Destinationid, destinationname, imageid, imagelink) values (105, 65, 'Vieux Lyon', 9, 'http://images.com/106x100.png/ff4444/ffffff')

select * from images;