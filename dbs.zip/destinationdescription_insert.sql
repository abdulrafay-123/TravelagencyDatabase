insert into destinationdescription (Memberid, destinationid, ModifiedDate) values (110, 52, '12/29/2021');
insert into destinationdescription (Memberid, destinationid, ModifiedDate) values (203, 21, '2/10/2022');
insert into destinationdescription (Memberid, destinationid, ModifiedDate) values (259, 2, '10/12/2021');
insert into destinationdescription (Memberid, destinationid, ModifiedDate) values (236, 40, '10/10/2021');
insert into destinationdescription (Memberid, destinationid, ModifiedDate) values (198, 36, '1/7/2022');
insert into destinationdescription (Memberid, destinationid, ModifiedDate) values (188, 12, '8/3/2021');
insert into destinationdescription (Memberid, destinationid, ModifiedDate) values (105, 65, '5/21/2021');
insert into destinationdescription (Memberid, destinationid, ModifiedDate) values (182, 37, '12/28/2021');
insert into destinationdescription (Memberid, destinationid, ModifiedDate) values (166, 87, '2/17/2022');
insert into destinationdescription (Memberid, destinationid, ModifiedDate) values (281, 66, '8/26/2021');

select * from destinationdescription;