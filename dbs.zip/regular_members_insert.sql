insert into regular_members (Memberid, number_of_followers) values (203, 9);
insert into regular_members (Memberid, number_of_followers) values (236, 11);
insert into regular_members (Memberid, number_of_followers) values (188, 3);
insert into regular_members (Memberid, number_of_followers) values (281, 15);
insert into regular_members (Memberid, number_of_followers) values (270, 9);
insert into regular_members (Memberid, number_of_followers) values (144, 2);
insert into regular_members (Memberid, number_of_followers) values (125, 13);
insert into regular_members (Memberid, number_of_followers) values (271, 18);
insert into regular_members (Memberid, number_of_followers) values (112, 16);
insert into regular_members (Memberid, number_of_followers) values (125, 8);
insert into regular_members (Memberid, number_of_followers) values (161, 10);
insert into regular_members (Memberid, number_of_followers) values (125, 13);
insert into regular_members (Memberid, number_of_followers) values (128, 11);
insert into regular_members (Memberid, number_of_followers) values (275, 14);
insert into regular_members (Memberid, number_of_followers) values (282, 2);
insert into regular_members (Memberid, number_of_followers) values (271, 16);
insert into regular_members (Memberid, number_of_followers) values (161, 10);
insert into regular_members (Memberid, number_of_followers) values (264, 1);
insert into regular_members (Memberid, number_of_followers) values (176, 1)
insert into regular_members (Memberid, number_of_followers) values (266, 2)

select * from regular_members;