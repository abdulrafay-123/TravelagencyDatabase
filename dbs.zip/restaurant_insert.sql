insert into restaurant (Consumption_per_capita, Weblink, Restaurant_Rating, destinationid) values (28, 'https://TexasRoadhouse.org', 1, 62);
insert into restaurant (Consumption_per_capita, Weblink, Restaurant_Rating, destinationid) values (43, 'https://MamasRestaurant.com', 3, 3);
insert into restaurant (Consumption_per_capita, Weblink, Restaurant_Rating, destinationid) values (25, 'https://HappysFishHouse.com', 1, 96);
insert into restaurant (Consumption_per_capita, Weblink, Restaurant_Rating, destinationid) values (8, 'https://VillaMontez.com', 4, 95);
insert into restaurant (Consumption_per_capita, Weblink, Restaurant_Rating, destinationid) values (38, 'https://ShahGhouseRestaurant.com', 5, 7);
insert into restaurant (Consumption_per_capita, Weblink, Restaurant_Rating, destinationid) values (16, 'http://TamraRestaurant.com', 4, 18);
insert into restaurant (Consumption_per_capita, Weblink, Restaurant_Rating, destinationid) values (34, 'http://ThespiceRoute.com', 3, 16);
insert into restaurant (Consumption_per_capita, Weblink, Restaurant_Rating, destinationid) values (8, 'https://MisterAsRestaurant.com', 3, 78);
insert into restaurant (Consumption_per_capita, Weblink, Restaurant_Rating, destinationid) values (11, 'https://PistahouseRestuarant.com', 5, 26);

select * from restaurant;