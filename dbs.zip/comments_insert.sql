insert into Comments (commentid, Memberid, Destinationid, posted_date, posted_time, Content, Rating, LikeDislike, reply_content) values (1, 110, 52, '1/3/2021', '2:46 PM', 'Ver Good', 3, 'Like', 'I totally Agree');
insert into Comments (commentid, Memberid, Destinationid, posted_date, posted_time, Content, Rating, LikeDislike, reply_content) values (2, 203, 21, '1/25/2021', '11:45 PM', 'Excellent Place', 1, 'Like', 'Yes it is right');
insert into Comments (commentid, Memberid, Destinationid, posted_date, posted_time, Content, Rating, LikeDislike, reply_content) values (3, 259, 2, '1/23/2021', '5:49 PM', 'I liked it alot', 2, 'Like', 'I feel so too');
insert into Comments (commentid, Memberid, Destinationid, posted_date, posted_time, Content, Rating, LikeDislike, reply_content) values (8, 236, 40, '2/16/2022', '1:26 AM', 'Its Awesome', 2, 'Like', 'I do not agree');
insert into Comments (commentid, Memberid, Destinationid, posted_date, posted_time, Content, Rating, LikeDislike, reply_content) values (5, 198, 36, '5/1/2021', '4:10 AM', 'This Place is horrendous', 5, 'Dislike', 'That might have been an exception');
insert into Comments (commentid, Memberid, Destinationid, posted_date, posted_time, Content, Rating, LikeDislike, reply_content) values (6, 188, 12, '3/1/2022', '3:20 AM', 'Not worth the money', 5, 'Dislike', 'Dont be so harsh');
insert into Comments (commentid, Memberid, Destinationid, posted_date, posted_time, Content, Rating, LikeDislike, reply_content) values (7, 105, 65, '1/8/2021', '11:48 PM', 'Not Maintained Properly', 2, 'Dislike', 'Yes its true');

select * from comments;
select *from view_6;