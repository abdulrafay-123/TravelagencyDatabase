insert into shopping (Weblink, destinationid) values ('https://GVKMall.com', 5);
insert into shopping (Weblink, destinationid) values ('http://InorbitMall.com', 98);
insert into shopping (Weblink, destinationid) values ('https://CityWalkMall.com', 25);
insert into shopping (Weblink, destinationid) values ('https://TheChanakyaMall.edu', 27);
insert into shopping (Weblink, destinationid) values ('http://TheGalleriaMall.com', 90);
insert into shopping (Weblink, destinationid) values ('https://CBRMall.com', 52);
insert into shopping (Weblink, destinationid) values ('https://infinitymall.com', 21);

select * from shopping;