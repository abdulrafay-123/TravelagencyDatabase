insert into wish_Destination (Memberid, wishlist) values
(105, 'Kalamazoo, Crocker Art Museuem, Falaknuma Palace, Art Institute of Chicago, CBR Mall, Red Fort, Faneuil Hall, Texas Roadhouse, Vieux Lyon'),
(110, 'Kalamazoo, Beaux-Arts museum, Roman amphitheatre, Happys Fish House'),
(112, 'Eifel Tower, Mamas Restaurant, Notre-Dame Cathedral'),
(122, 'Eifel Tower, Mamas Restaurant, GVK Mall, Shah Ghouse Restaurant, House of Blues Dallas'),
(125, 'The Sice Route, Great Wall of China, Tamra Restaurant, Notre-Dame Cathedral'),
(277, 'Eifel Tower, Shah Ghouse Restaurant, House of Blues Dallas, Connecticut River Walk, Vieux Port, The Sice Route, Great Wall of China, Tamra Restaurant, Stonestown Galleria, infinity mall'),
(279, 'Crocker Art Museuem, Art Institute of Chicago, CBR Mall, Texas Roadhouse, Vieux Lyon'),
(281, 'Kalamazoo, Crocker Art Museuem, CBR Mall, Red Fort, Faneuil Hall, Texas Roadhouse, Vieux Lyon'),
(285, 'infinity mall, Salarjung Museum, Notre-Dame Cathedral, Petite France district, Brickell City Centre, Eifel Tower'),
(286, 'CityWalk Mall, Pista House Restaurant, The Chanakya Mall, Museum of the American GI, Eifel Tower, Red Fort, Notre-Dame Cathedral'),
(290, 'Eifel Tower, Notre-Dame Cathedral, CityWalk Mall, Pista House Restaurant, The Chanakya Mall, Petite France district, Brickell City Centre');

select * from wish_destination;

